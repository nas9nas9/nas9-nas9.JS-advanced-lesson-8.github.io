
export const environment = {

  firebase: {
      apiKey: "AIzaSyA_I3y2VCm6lEv7CL_VHkX5eux2aOKv7Yc",
      authDomain: "monosushi-adb00.firebaseapp.com",
      projectId: "monosushi-adb00",
      storageBucket: "monosushi-adb00.appspot.com",
      messagingSenderId: "301869728963",
      appId: "1:301869728963:web:9e16550425d64d48728e76"
  },

  production: false,
  BACKEND_URL: "http://localhost:3000"
};
